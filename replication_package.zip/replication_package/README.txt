This is part of the bundle including the code and benchmarks required to replicate the experiments described in the paper 
"A validation methodology for XAI decision support systems against relational domain properties" by 
Emanuele De Angelis (CNR-IASI, Rome, Italy), Guglielmo De Angelis (CNR-IASI, Rome, Italy), 
Maurizio Mongelli (CNR-IEIIT, Rome, Italy), and Maurizio Proietti (CNR-IASI, Rome, Italy).


--- 
Description of the bundle content:

(1) 'Simulator_V18_Q4_rules_20230908_182047.clp',
    including the CLP encoding of the CHCs representing the classifier used as case study.
    The deterministic rule-based classifier is available here: https://zenodo.org/records/10078165

(2) 'domain_properties.pl',
    including the CLP encoding of the relational domain properties

(3) 'answers_20240219-data.out',
    including the answers computed to check the correctness of (1) w.r.t. (2)

(4) 'processed-answers_20240624-data-v3.tar.gz',
    including the .csv files with the data, extracted from the answers (3),
    used to estimate the impact of the counter-examples 

(5) 'holds_interpreter.pl', 'utils.pl', and 'vartypes.pl',
    including the Prolog implementation to generate the answers (3)
    Instructions to replicate the experiments are described here: 
    https://github.com/IASI-SAKS/openness/tree/main/rules-validation/prolog#checking-the-properties

(6) 'README.txt', this file


---
ADDITIONAL LINKS

1) RuleX Model: https://github.com/IASI-SAKS/openness/blob/main/Rulex/README.md

2) Simulator: https://github.com/IASI-SAKS/openness/tree/main/Simulator_V18

3) SWI-Prolog: https://www.swi-prolog.org/
